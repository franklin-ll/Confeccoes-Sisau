package confeccoessisaulayout;

import br.com.classes.Cliente;
import br.com.classes.Venda;
import br.com.hibernate.HibernateUtil;
import java.util.Date;
import org.hibernate.Session;

public class ConfeccoesSisauLayout {

    public static void main(String[] args) {
    Session session = HibernateUtil.getSessionFactory().openSession();
    session.beginTransaction();
    
    Cliente cliente = new Cliente();
        
    cliente.setCpf_cnpj("04687617126");
    cliente.setData_nascimento(new Date());
    cliente.setNome("Sibelly G. Sanches Cavalcante");
    cliente.setPassaporte("9392349348948223");
    cliente.setRg("001866799");
        
    Venda venda = new Venda();
    venda.setCliente(cliente);
    venda.setDesconto(12.12);
    venda.setQuantidade(20);
    venda.setDataVenda(new Date());
    venda.setTotal(25.00);
    
    session.save(cliente);
    session.save(venda);
    
    session.getTransaction().commit();
    
    }  
}
