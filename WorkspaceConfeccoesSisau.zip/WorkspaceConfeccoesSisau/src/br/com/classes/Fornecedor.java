package br.com.classes;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tb_fornecedor")
public class Fornecedor extends Pessoa {
    
    private String nomeEmpresa;

    /*Construtor Padrao*/
    public Fornecedor(){
    }
    
    /*Getters & Setters*/
    public String getNomeEmpresa() {
        return nomeEmpresa;
    }
    public void setNomeEmpresa(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }    
}
