package br.com.classes;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "tb_compra")
public class Compra implements Serializable {
    
    @Id
    @Column(name="codigo_compra")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)         
    private Integer id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="gerente_fk", insertable=true, updatable=true) 
    @Fetch(FetchMode.JOIN) 
    @Cascade(CascadeType.SAVE_UPDATE)         
    private Gerente gerente; 
    
    @ManyToMany
    @JoinTable(name="tb_produto_compra",joinColumns={@JoinColumn(name="codigo_compra")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_produto")})
    private List<Produto> produtos;    
    
    @Column(name="data_compra") 
    @Temporal(TemporalType.TIMESTAMP)    
    private Date dataCompra;
        
    private Integer quantidade;
    private Double valor;
  
    /*Construtor Padrao*/
    public Compra(){
    }    
    
    /*Getters & Setters*/
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        this.gerente = gerente;
    }    

    public Date getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(Date dataCompra) {
        this.dataCompra = dataCompra;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}

