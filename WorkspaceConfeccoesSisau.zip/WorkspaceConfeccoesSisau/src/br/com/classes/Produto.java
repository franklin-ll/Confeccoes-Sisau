package br.com.classes;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "tb_produto")
public class Produto implements Serializable {
  
    @Id
    @Column(name="codigo_produto")    
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    
    @ManyToMany
    @JoinTable(name="tb_produto_compra",joinColumns={@JoinColumn(name="codigo_produto")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_compra")})
    private List<Compra> compras;  
    
    @ManyToMany
    @JoinTable(name="tb_produto_venda",joinColumns={@JoinColumn(name="codigo_produto")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_venda")})
    private List<Venda> vendas;
    
    private String nome;
    private String categoria;
    private String cor;
    private String marca;
    private String tamanho;
    private Integer quantidade;
    private Double preco;
    
    /*Construtor Padrao*/
    public Produto(){
    }    

    /*Getters & Setters*/
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }    
}

