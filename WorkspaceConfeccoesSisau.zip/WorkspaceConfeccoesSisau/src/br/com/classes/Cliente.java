package br.com.classes;

import javax.persistence.*;

@Entity
@Table(name = "tb_cliente")
public class Cliente extends Pessoa{
    
    private String rg;
    
    /*Construtor Padrao*/
    public Cliente(){
    }

    /*Getters & Setters*/   
    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }
}
