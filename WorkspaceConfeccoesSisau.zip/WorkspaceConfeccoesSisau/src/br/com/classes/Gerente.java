package br.com.classes;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tb_gerente")
public class Gerente extends Pessoa {
    
    private Double salario;
    
    /*Construtor Padrao*/
    public Gerente(){
    }

    /*Getters & Setters*/
    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }    
}
