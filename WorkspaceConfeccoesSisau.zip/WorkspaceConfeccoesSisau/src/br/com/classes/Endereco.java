package br.com.classes;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tb_endereco")
public class Endereco implements Serializable {
    
    @Id
    @Column(name="codigo_endereco")    
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    
    @ManyToMany
    @JoinTable(name="tb_endereco_pessoa",joinColumns={@JoinColumn(name="codigo_endereco")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_pessoa")})
    private List<Pessoa> pessoas;      
    
    private String rua;
    private Integer numero;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;
    private String complemento;
    
    
    
    
}
