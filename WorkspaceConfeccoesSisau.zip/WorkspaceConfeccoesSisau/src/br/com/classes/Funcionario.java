package br.com.classes;

import javax.persistence.*;

@Entity
@Table(name = "tb_funcionario") 
public class Funcionario extends Pessoa{
    
    private Double salario;
    
    /*Construtor Padrao*/
    public Funcionario(){
    }    

    /*Getters & Setters*/
    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }
}

