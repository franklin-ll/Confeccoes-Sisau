package br.com.classes;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "tb_pessoa")
@Inheritance(strategy=InheritanceType.JOINED) 
public class Pessoa implements Serializable {
    
    @Id 
    @GeneratedValue(strategy = GenerationType.SEQUENCE) 
    @Column(name="codigo_pessoa") 
    private Integer id;    
   
    @ManyToMany
    @JoinTable(name="tb_endereco_pessoa",joinColumns={@JoinColumn(name="codigo_pessoa")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_endereco")})
    private List<Endereco> enderecos;   
    
    @ManyToMany
    @JoinTable(name="tb_telefone_pessoa",joinColumns={@JoinColumn(name="codigo_pessoa")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_telefone")})
    private List<Telefone> telefones;      
    
    private String cpf_cnpj;
    private String passaporte;
    private String nome;
    
    @Column(name="data_nascimento") 
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataNascimento;
    
    /*Construtor Padrao*/
    public Pessoa(){
    }
    
    /*Getters & Setters*/
    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }    

    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }
    
    public String getCpf_cnpj() {
        return cpf_cnpj;
    }

    public void setCpf_cnpj(String cpf_cnpj) {
        this.cpf_cnpj = cpf_cnpj;
    }

    public String getPassaporte() {
        return passaporte;
    }

    public void setPassaporte(String passaporte) {
        this.passaporte = passaporte;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getData_nascimento() {
        return dataNascimento;
    }

    public void setData_nascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }  

}

