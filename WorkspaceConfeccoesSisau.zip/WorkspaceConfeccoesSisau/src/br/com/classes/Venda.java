package br.com.classes;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "tb_venda")
public class Venda implements Serializable{
    
    @Id
    @Column(name="codigo_venda") 
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="cliente_fk", insertable=true, updatable=true) 
    @Fetch(FetchMode.JOIN) 
    @Cascade(CascadeType.SAVE_UPDATE)         
    private Cliente cliente;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="fornecedor_fk", insertable=true, updatable=true) 
    @Fetch(FetchMode.JOIN) 
    @Cascade(CascadeType.SAVE_UPDATE)         
    private Fornecedor fornecedor;   
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="funcionario_fk", insertable=true, updatable=true) 
    @Fetch(FetchMode.JOIN) 
    @Cascade(CascadeType.SAVE_UPDATE)         
    private Funcionario funcionario;     

    @ManyToMany
    @JoinTable(name="tb_produto_venda",joinColumns={@JoinColumn(name="codigo_venda")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_produto")})
    private List<Produto> produtos;    
    
    @Column(name="data_venda") 
    @Temporal(TemporalType.TIMESTAMP)    
    private Date dataVenda;    
    
    private Double desconto;
    private Integer quantidade;
    private Double total;
 
    /*Construtor Padrao*/
    public Venda(){
    }    
    
    /*Getters & Setters*/
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
 
    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }    

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }
}

