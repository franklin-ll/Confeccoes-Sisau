package br.com.classes;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tb_telefone")
public class Telefone implements Serializable {
    
    @Id
    @Column(name="codigo_telefone")    
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    
    @ManyToMany
    @JoinTable(name="tb_telefone_pessoa",joinColumns={@JoinColumn(name="codigo_telefone")}
    ,inverseJoinColumns={@JoinColumn(name="codigo_pessoa")})
    private List<Pessoa> pessoas;    
    
    private Integer ddd;
    private Integer numero;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /*Getters & Setters*/
    public void setId(Integer id) {
        this.id = id;
    }

    public List<Pessoa> getPessoas() {
        return pessoas;
    }

    public void setPessoas(List<Pessoa> pessoas) {
        this.pessoas = pessoas;
    }

    public Integer getDdd() {
        return ddd;
    }

    public void setDdd(Integer ddd) {
        this.ddd = ddd;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }
}
